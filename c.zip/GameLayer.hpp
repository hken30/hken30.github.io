//
//  GameLayer.hpp
//  AirHockey-mobile
//
//  Created by hken on 05/05/2019.
//

#ifndef GameLayer_hpp
#define GameLayer_hpp

#define GOAL_WIDTH 400

#include "cocos2d.h"
#include "GameSprite.hpp"
using namespace cocos2d;
class GameLayer : public Layer
{
    GameSprite* _player1;
    GameSprite* _player2;
    GameSprite* _ball;
    
    Vector<GameSprite*> _players;
    Label* _player1ScoreLabel;
    Label* _player2ScoreLabel;
    
    Size _screenSize;
    int _player1Score;
    int _player2Score;
    
    void playerScore (int player);
    
public:
    GameLayer();
    virtual ~GameLayer();
    
    virtual bool init();
    
    static Scene* scene();
    
    CREATE_FUNC(GameLayer);
    void onTouchesBegan(const std::vector<Touch*> &touches,
                        Event* event);
    void onTouchesMoved(const std::vector<Touch*> &touches,
                        Event* event);
    void onTouchesEnded(const std::vector<Touch*> &touches,
                        Event* event);
    void update (float dt);
};
#endif /* GameLayer_hpp */
