//
//  GameSprite.hpp
//  AirHockey-mobile
//
//  Created by hken on 05/05/2019.
//

#ifndef GameSprite_hpp
#define GameSprite_hpp

#include "cocos2d.h"

using namespace cocos2d;

class GameSprite : public Sprite {
public:
    CC_SYNTHESIZE(Vec2, _nextPosition, NextPosition);
    CC_SYNTHESIZE(Vec2, _vector, Vector);
    CC_SYNTHESIZE(Touch*, _touch, Touch);
    
    GameSprite();
    virtual ~GameSprite();
    
    static GameSprite* gameSpriteWithFile(const char* pszFileName);
    virtual void setPosition(const Vec2& pos) override;
    float radius();
};

#endif /* GameSprite_hpp */
